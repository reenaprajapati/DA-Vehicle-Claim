# DATA ANALYSIS FOR VEHICLE CLAIMS  

# TEAM MEMBERS: CSE DEPARTMENT

711715104048-Reena.D,
711715104052-Sathyan.S,
711715104072-Vinayagamoorthy.G

# ABSTRACT
           A system that helps in visualizing and analysing the motor insurance vehicle claims. It distributes interactive and sharable dashboards which depict the trends variations and density of the data in form of graphs and charts. It will be  useful for future prediction and comparison of data.Claims analysis is a technique for examining the positive and negative consequences of design features that are described in current or future scenarios of use. A "claim" is a statement of the consequences of a specific design feature or artifact on users and other stakeholders. This system is planned to build using the TABLEAU software to visualise the data.
   
# FUTURE ENHANCEMENT
           In future we are going to make the project more flexible for adapting new technologies.Also we have a plan to process artificial intelligence in our project.Support will always be given to all our customers and any queries regarding to our project will be resolved.Additional tools will be added and the feedback,support page will be added so that the user’s opinion will be considered.
Constant updates will be provided and security will always be in a consideration and will be improved.Data security is our top priority and we make sure any data without our knowledge will not be leaked.

# ADVANTAGE:

1.Working on large number of data using TABLEAU
2.Classify the insurance claim details
3.Visualizing the data in the form of charts and graphs.
4.Predict the types of claims.
5.Future Prediction
